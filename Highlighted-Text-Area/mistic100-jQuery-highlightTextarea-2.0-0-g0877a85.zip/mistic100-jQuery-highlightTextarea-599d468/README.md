jQuery highlightTextarea
========================

Overview
--------
highlightTextarea is a jQuery plugin which allows you to highlight words and sentences into textareas. Words are defined in a jQuery array and you can customize highlight color and case sensitivity. The highlighting updates itself when typing in the textarea and follows scroll and resizing (with jQuery-UI).

Documentation, Features and Demos
---------------------------------
Full details and documentation can be found on the project page here:

<http://www.strangeplanet.fr/work/jquery-highlighttextarea/>